const api           = require('./api.route');

module.exports = {
    api,
}